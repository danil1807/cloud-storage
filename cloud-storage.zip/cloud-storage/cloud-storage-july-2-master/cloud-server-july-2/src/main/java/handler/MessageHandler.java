package handler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import lombok.extern.slf4j.Slf4j;
import model.*;

@Slf4j
public class MessageHandler extends SimpleChannelInboundHandler<AbstractCommand> {

    private Path currentPath;

    public MessageHandler() throws IOException {
        currentPath = Paths.get("server_dir");
        if (!Files.exists(currentPath)) {
            Files.createDirectory(currentPath);
        }
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        ctx.writeAndFlush(new ListResponse(currentPath));
        ctx.writeAndFlush(new PathResponse(currentPath.toString()));
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, AbstractCommand command) throws Exception {
       // log.debug("received: {}", command.getType());
        switch (command.getType()) {
            case FILE_REQUEST:
                FileRequest fileRequest = (FileRequest) command;
                FileDownload msg = new FileDownload(currentPath.resolve(fileRequest.getName()));
                ctx.writeAndFlush(msg);
                break;
            case FILE_UPLOAD:
                FileUpload message = (FileUpload) command;
                Files.write(currentPath.resolve(message.getName()), message.getData(), StandardOpenOption.APPEND);
                ctx.writeAndFlush(new ListResponse(currentPath));
                break;
            case PATH_UP:
                if (currentPath.getParent() != null) {
                    currentPath = currentPath.getParent();
                }
                ctx.writeAndFlush(new PathResponse(currentPath.toString()));
                ctx.writeAndFlush(new ListResponse(currentPath));
                break;
            case LIST_REQUEST:
                ctx.writeAndFlush(new ListResponse(currentPath));
                break;
            case PATH_IN_REQUEST:
                PathInRequest request = (PathInRequest) command;
                Path newPath = currentPath.resolve(request.getDir());
                if (Files.isDirectory(newPath)) {
                    currentPath = newPath;
                    ctx.writeAndFlush(new PathResponse(currentPath.toString()));
                    ctx.writeAndFlush(new ListResponse(currentPath));
                }
                break;
            case RENAME_REQUEST:
                RenameRequest renameRequest = (RenameRequest) command;
                Path oldPath = currentPath.resolve(renameRequest.getOldName());
                Path newPath1 = currentPath.resolve(renameRequest.getNewName());
                Files.move(oldPath,newPath1);
                ctx.writeAndFlush(new PathResponse(currentPath.toString()));
                ctx.writeAndFlush(new ListResponse(currentPath));
                break;
            case LIST_SORT_AZ_REQUEST:
                ctx.writeAndFlush(new ListSortAZResponse(currentPath));
                break;
            case FOLDER_CREATE_REQUEST:
                FolderCreateRequest folderCreateRequest = (FolderCreateRequest) command;
                Path newDirectory = Files.createDirectories(folderCreateRequest.getPath());
                //ctx.writeAndFlush(new FolderCreateResponse(newDirectory));
                ctx.writeAndFlush(new ListResponse(currentPath));
        }
    }
}
