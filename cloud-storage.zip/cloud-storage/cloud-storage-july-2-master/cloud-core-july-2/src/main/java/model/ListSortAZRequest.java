package model;


import java.nio.file.Path;

public class ListSortAZRequest extends AbstractCommand{

    public ListSortAZRequest() {

    }

    @Override
    public CommandType getType() {
        return CommandType.LIST_SORT_AZ_REQUEST;
    }


}
