package model;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ListSortAZResponse extends AbstractCommand{
    private final List<String> names;

    public ListSortAZResponse (Path path) throws IOException {
        names = Files.list(path)
                .map(p -> p.getFileName().toString())
                .sorted(Comparator.naturalOrder())
                .collect(Collectors.toList());
    }


    public List<String> getNames() {
        return names;
    }

    @Override
    public CommandType getType() {
        return CommandType.LIST_SORT_AZ_RESPONSE;
    }
}
