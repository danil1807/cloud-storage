package model;

import java.nio.file.Path;

public class FolderCreateRequest extends AbstractCommand{
    private Path path;

    public FolderCreateRequest(Path path) {
        this.path = path;
    }

    public Path getPath() {
        return path;
    }

    @Override
    public CommandType getType() {
        return CommandType.FOLDER_CREATE_REQUEST;
    }
}
